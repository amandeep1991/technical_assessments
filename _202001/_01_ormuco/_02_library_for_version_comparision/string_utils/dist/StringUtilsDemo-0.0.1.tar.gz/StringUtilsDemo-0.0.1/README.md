This is just a demo string utils package for our own understanding, steps followed:
1. Move to directory: 'technical_assessments\_202001\_01_ormuco\_02_library_for_version_comparision\string_utils'
2. Execute command: 'python setup.py sdist' - **To builds a source distribution (a tar archive of all the files needed to build and install the package)**
3. Execute command: 'python setup.py bdist_wheel' - **Builds wheels**.
4. Move to 'technical_assessments\_202001\_01_ormuco\_02_library_for_version_comparision\string_utils\dist'
5. Install the package by executing command: 'pip install StringUtilsDemo-0.0.1-py3-none-any.whl'
6. Now you are good to run 'technical_assessments\_202001\_01_ormuco\_02_library_for_version_comparision\_02_library_for_version_comparision.py'